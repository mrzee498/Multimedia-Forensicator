<?php include_once("partials/header.php"); ?>
<body>
	<script type="text/javascript">
		// SEARCH FOR REF NUMBER
		function fileAnalysis(){
			var xmlhttp;
			if(window.XMLHttpRequest){
				xmlhttp = new XMLHttpRequest();
			}else{
				xmlhttp = new ActiveXObject("Microsoft:XMLHTTP");
			}
			
			xmlhttp.onreadystatechange = function(){
				if(this.readyState==4 && this.status==200){
					document.getElementById("result_div").innerHTML=this.responseText;
				}
			}
			// var progress_bar ='<img src="assets/img/processing.gif" />';
			var progress_bar ='<img src="assets/img/reload.gif" />';
			
			xmlhttp.open("GET","analyseFile.php",true);
			document.getElementById("result_div").innerHTML = progress_bar;
			xmlhttp.send();
		}
	</script>

	<div class="container">
		<h1 class="text-danger"> &nbsp; </h1>
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-10 col-xs-12">
				<div class="panel panel-info">
					<div class="panel-heading">  </div>
					<h1 class="text-danger text-center">Multimedia Forensicator</h1>
					<div class="text-center" >
						<!-- multimedia logos AUDIO-->
						<img src="assets/img/image.PNG" width="50" height="50" class="img-responsive img-thumbnail" /> &nbsp; &nbsp;
						<img src="assets/img/audio.PNG" width="50" height="50" class="img-responsive img-thumbnail" /> &nbsp; &nbsp;
						<img src="assets/img/video.png" width="50" height="50" class="img-responsive img-thumbnail" /> <br /> <br />
						<code>Images(jpg)</code> &nbsp;  <code>Audios(mp3)</code> &nbsp; <code>Videos(mp4)</code>
					</div>

					<div class="panel-body">
						<div class="row">
							<div class="col-lg-10 col-lg-offset-1 col-md-10 col-md-offset-1 col-sm-8 col-sm-offset-1 col-xs-10 col-xs-offset-1">
								<!-- <img src="assets/img/audio_logo.png" class="img-thumbnail img-responsive" /> -->
								<div class="row"><!-- log errors FLASH MESSAGESS -->
									<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<?php 
											// end of login errors FLASH MESSAGES
											if(isset($_GET['log_error'])){
												$log_error = $_GET['log_error']; ?>
												<div class="text-center text-danger">
														<h4><i class="fa fa-times"></i> <?php echo $log_error; ?></h4>
												</div>
											<?php
											}
										
											// log SUCCESS FLASH MESSAGESS
											if(isset($_GET['log_success'])){
												$log_success = $_GET['log_success'];
												?>
												<div class="text-center text-success">
													<h4><i class="fa fa-check"></i> <?php echo $log_success; ?></h4>
												</div>
										<?php } ?>
									</div>
								</div> <!--/. row ends... log errors ends...-->

								<form ENCTYPE="multipart/form-data" method="POST">
									<br /><h4 class="text-muted">Select a File to Upload</h4>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon"> <i class="fa fa-upload"></i></span>
											<input type="file" name="file_upload" id="file_upload" class="form-control" required >
										</div>
										
										<div class="form-group text-center">
											<br />
											<button class="btn btn-primary btn-md" name="btnUpload" formaction="fileUpload.php"><i class="fa fa-upload"></i> Upload File </button><br />
										</div>
									</div>
								</form>
							</div><!--/. col ends...-->
						</div> <!--/. row ends...-->

					</div><!--/. Panel body ends...-->
				</div> <!--/. Panel ends...-->
			</div> <!--/. LEFT col ends...-->

			<div class="col-lg-6 col-md-6 col-sm-10 col-xs-12">
				<div class="panel panel-success">
					<div class="panel-heading"> PERFORM FORENSIC ANALYSIS </div>
					<div class="panel-body">
						
						<div class="text-center text-danger">
							<h4>Click this button to Perform Analysis <br /> <i class="fa fa-sort-down"></i> </h4>
						</div>

						<form>
							<!-- show ANALYSIS BUTTON IF UPLOAD SUCCESSFUL -->
							<div class="form-group text-center">
								<a class="btn btn-primary btn-lg" name="btnVerify" onClick="fileAnalysis()" > 
									<i class="fa fa-refresh"></i> ForeNsic ANALYSIS</a><br />
							</div>
						</form>
						
						<!-- DISPLAY ANALYSIS RESULT HERE -->
						<div id="result_div" class="text-center"></div>

					</div> <!--/. Panel body ends...-->
				</div> <!--/. Panel ends...-->
			</div> <!--/. RIGHT col ends...-->
		</div><!--/. row ends...-->

		<br /><br /><br />

	</div><!--/. container ends...-->
<?php include_once("partials/footer.php");	?>