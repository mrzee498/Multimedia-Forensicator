<?php ob_start(); ?>
<?php include_once("partials/header.php"); ?>

<?php 
  $sql_query = mysqli_query($connection, "SELECT * FROM file_analysis");
  while($row = mysqli_fetch_assoc($sql_query) ){
    $file_name = $row['f_name'];
    $file_size = $row['f_size'];
    $f_type = $row['f_type'];
    $directory = $row['directory'];
    $hex_value = $row['hex_value'];
    $num_chars = intval($row['num_chars']);
    $c_time = date ("F d Y, H:i:s", filectime($directory));
    $m_time = date ("F d Y, H:i:s", filemtime($directory));

    $file_type = explode("/", $f_type);
    $file_category = $file_type[0];
    $file_format = $file_type[1];
    $hex = explode(" ", $hex_value);
  }

  //ANALYSIS OUTPUT
  $format_status = false; $digital_signature = false; $status_report = ""; $signature_type = ""; $signature_subtype = "";

  //perform VIDEO analysis
  function videoAnalysis(){
    global $connection, $format_status, $digital_signature, $hex, $num_chars, $file_format;
    global $signature_type, $signature_subtype, $status_report;

    //SQL TO GET FILE SIGNATURE TYPES
    $sql_query = mysqli_query($connection, "SELECT * FROM video WHERE file_format = '{$file_format}' ");
    while($row = mysqli_fetch_array($sql_query) ){
      $all_types = $row['signature_type'];
      $all_subtypes = $row['signature_subtype'];
    }

    //create arrays of signature types and subtypes
    $signature_type = explode(", ", $all_types);
    $signature_subtype = explode(", ", $all_subtypes);
    
    //======================================
              //MP4 AUTHENTICATION
    //=====================================
    function mp4Authentication(){    
      global $connection, $format_status, $digital_signature, $hex, $num_chars, $file_format;
      global $signature_type, $signature_subtype, $status_report;

      //DATA FROM THE FIRST CHUNK
      $firstChunk_size = $hex[0] + $hex[1] + $hex[2] + $hex[3];
      $firstChunk_type = chr($hex[4]).chr($hex[5]).chr($hex[6]).chr($hex[7]); //convert back to ascii character
      $firstChunk_subtype = chr($hex[8]).chr($hex[9]).chr($hex[10]).chr($hex[11]);
        
      //VERIFY THE FIRST CHUNK
      if( ($firstChunk_type) === $signature_type[0] ){ //$first_chunk_type
        // echo $firstChunk_subtype."<br>";
        // print_r($signature_subtype)."<br>";
        // echo !in_array("avc1", $signature_subtype)."<br>";
      
        // echo gettype($firstChunk_subtype)."<br>";
        // echo gettype($signature_subtype[8])."<br>";
        // echo $signature_subtype[8]."<br>";

        if( in_array($firstChunk_subtype, $signature_subtype) ){ //$first_chunk_subtype
          $format_status = true; // has a valid format type

          //create second chunk data
          $secondChunk_offset = $firstChunk_size;
          $secondChunk_size = $hex[$secondChunk_offset] + $hex[$secondChunk_offset+1] + $hex[$secondChunk_offset+2] + $hex[$secondChunk_offset+3];
          $secondChunk_type = chr($hex[$secondChunk_offset+4]). chr($hex[$secondChunk_offset+5]). chr($hex[$secondChunk_offset+6]). chr($hex[$secondChunk_offset+7]);

        }else{ // break away from the loop if the subtype is not valid
          $format_status = false;
          $status_report .= "<p>The video is NOT a valid mp4 file, and the DIGITAL Signature is not verified.</p>";
        }

        if($format_status){
          //PERFORM CHECKS FROM THE 16TH - 23RD OFFSET LOCATION
          $sixtent_offset = chr($hex[16]).chr($hex[17]).chr($hex[18]).chr($hex[19]); //offset location between 16 - 19
          $twentiet_offset = chr($hex[20]).chr($hex[21]).chr($hex[22]).chr($hex[23]); //offset location between 20 - 23

          //VERIFY THE SECOND CHUNK
          for($i = 0; $i < sizeof($signature_type); $i++){//verify from the signature sub types from the database
            if( in_array($secondChunk_type, $signature_type) ){ //$first_chunk_subtype
              //offset location between 16 -  - 23
              if( in_array($sixtent_offset, $signature_subtype) && in_array($twentiet_offset, $signature_subtype)  ){ 
                
                if( ($sixtent_offset === "MSNV") || ($twentiet_offset === "MSNV") ){ //recorded from web cameras
                  $digital_signature = true;
                  $status_report = "<p>The video is a valid mp4 file, and the DIGITAL Signature is VERIFIED.</p>";
                }else if( ($sixtent_offset === "MSNV") || ($twentiet_offset === "MSNV") ){ //recorded with a mobile phone
                  $digital_signature = true;
                  $status_report = "<p>The video is a valid mp4 file, and the DIGITAL Signature is VERIFIED.</p>";
                }else{ // INVALID SIGNATURE
                  if( ($sixtent_offset === "mp41") && ($twentiet_offset === "isom") ){
                    $status_report = "<p><b>REASON:</b> Some frames were removed from the original copy. </p>";
                  }else if( ($sixtent_offset === "isom") && ($twentiet_offset === "iso2") ){
                    $status_report = "<p><b>REASON:</b> The frames were converted from another format. </p>";
                  }else{
                    //$digital_signature = true;
                    $status_report = "<p>The video is a valid mp4 file, but the DIGITAL Signature is not verified.</p>";
                  }
                  
                }

              }else{ 
                $status_report = "<p>The video is a valid mp4 file, but the DIGITAL Signature is not verified.</p>";
                break; // break away from the loop if the //offset location between 16 - 23 is not valid
              }
            }else{ 
              $status_report = "<p>The video is a valid mp4 file, but the DIGITAL Signature is not verified.</p>";
              break; // break away from the loop if the $secondChunk_type is not valid
            }
          }
          if(isset($subs)){echo $subs;}
        }
        
      }//valid first chunk type ends...
    }//.MP4 AUTHENTICATION ENDS...

    if($file_format === "mp4"){
      mp4Authentication();
    }

  }// end of VIDEO analysis...

  //perform IMAGE analysis
  function imageAnalysis(){
    global $connection, $format_status, $digital_signature, $hex, $num_chars, $file_format, $status_report;
    //global $signature_type, $signature_subtype;

    //SQL TO GET FILE SIGNATURE TYPES
    $sql_query = mysqli_query($connection, "SELECT * FROM `image` WHERE file_format = '{$file_format}' ");
    while($row = mysqli_fetch_array($sql_query) ){
      $all_types = $row['signature_type'];
      $all_subtypes = $row['signature_subtype'];
    }

    //create arrays of signature types and subtypes
    // $signature_type = explode(",", $all_types);
    // $signature_subtype = explode(",", $all_subtypes);
    
    //======================================
              //JPG AUTHENTICATION
    //=====================================
    function jpgAuthentication(){    
      global $connection, $format_status, $digital_signature, $hex, $num_chars, $file_format, $status_report;
      //global $signature_type, $signature_subtype;

      $offset0 = intval($hex[0]); $offset1 = intval($hex[1]); $offset2 = intval($hex[2]); $offset3 = intval($hex[3]);
       
      if( ($offset0 === 255 && $offset1 === 216 && $offset2 === 255) && ($offset3 === 224 || $offset3 === 225 || $offset3 === 232) ){     
        if( (intval($hex[$num_chars-1]) === 217) && (intval($hex[$num_chars-2]) === 255)  ){ // checking the last two offset values
             $format_status = true;

          if($format_status){
            $offset22 = intval($hex[22]);
            $offset23 = intval($hex[23]);
            if( ($offset22 === 37 && $offset23 === 60) || ($offset22 === 172 && $offset23 === 82) || ($offset22 === 16 && $offset23 === 220) || ($offset22 === 0 && $offset23 === 67) || ($offset22 === 16 && $offset23 === 110) || ($offset22 === 16 && $offset23 === 12) || ($offset22 === 25 && $offset23 === 188) || ($offset22 === 37 && $offset23 === 136) || ($offset22 === 14 && $offset23 === 1) ){  
              $digital_signature = true;
            }
          }
        }else{
          $status_report = "It is not a valid JPEG Format";
        }// checking the last two offset values ends...
      }else{
        $status_report = "It is not a valid JPEG Format";
      }//valid format type ends...

    }//.JPG AUTHENTICATION ENDS...

    if( ($file_format === "jpg") || ($file_format === "jpeg") ){
      jpgAuthentication();
    }
  }// end of IMAGE analysis...

  //perform AUDIO analysis
  function audioAnalysis(){
    global $connection, $format_status, $digital_signature, $hex, $num_chars, $file_format;
    global $signature_type, $signature_subtype, $status_report;

    //SQL TO GET FILE SIGNATURE TYPES
  
    
    //======================================
              //MP3 AUTHENTICATION
    //=====================================
    function mp3Authentication(){    
      global $connection, $format_status, $digital_signature, $hex, $num_chars, $file_format;
      global $signature_type, $signature_subtype, $status_report;

      //DATA FROM THE FIRST CHUNK
      //$firstChunk = $hex[0] + $hex[1] + $hex[2] + $hex[3];
      $firstChunk = chr($hex[4]).chr($hex[5]).chr($hex[6]).chr($hex[7]); //convert back to ascii character
        
      //VERIFY THE FIRST CHUNK
      //255 251 196 096
      //255 251 148 100
      //073 068 051
      if( ( ($hex[0]==255) && ($hex[1]==251) && ($hex[2]==196) && ($hex[3]==96)) || (($hex[0]==73) && ($hex[1]==68) && ($hex[2]==51)) || ( ($hex[0]==255) && ($hex[1]==251) && ($hex[2]==148) && ($hex[3]==100)) ){ //$first_chunk_type
        $format_status = true;
        
        if($format_status){
          
          if( ($hex[2]==196) && ($hex[3]==96) ){
            $digital_signature = true;
          }
          

        
        }
        
        
      }//valid first chunk type ends...
    }//.MP3 AUTHENTICATION ENDS...

    if($file_format === "mp3"){
      mp3Authentication();
    }
  }// end of AUDIO analysis...

  //INVLAID FILE SELECTION (runs when an invalid file format is selected)
  function noAnalysis(){
    echo "Hello, no file selection is made";
  } // end of no analysis...

  //CHOOSE THE FUNCTION TO CALL BASED ON THE FILE TYPE
  if($file_category === "video"){
    videoAnalysis();
  }else if($file_category === "audio"){
    audioAnalysis();
  }else if($file_category === "image"){
    imageAnalysis();
  }else{
    noAnalysis();
  }
 

  //COMPILE THE FIRST PART OF THE REPORT IN HTML
  
  $html = '
    <br /><div class="row"><div class="col-lg-12"></div></div>

    <h4 class="text-left"><code><i class="fa fa-tasks"></i> UPLOADED FILE DETAILS</code></h4>
    <div class="list-group text-left">
      <a class="list-group-item">
          <i class="fa fa fa-file-archive-o fa-fw"></i> File Type
          <span class="pull-right text-muted">'.$file_category.'</span></a>

      <a class="list-group-item">
        <i class="fa fa fa-filter fa-fw"></i> Format
        <span class="pull-right text-muted">'.$file_format.'</span></a>

      <a class="list-group-item">
        <i class="fa fa-tags fa-fw"></i> Name
        <span class="pull-right text-muted">'.$file_name.'</span></a>

      <a class="list-group-item">
          <i class="fa fa-hdd-o"></i> File size
          <span class="pull-right text-muted">'.number_format(floor($file_size/1024),0). ' KB</span></a>

     
    </div>

    <br />
    <h4 class="text-left"><kbd><i class="fa fa-refresh"></i> RESULT OF FILE ANALYSIS </kbd></h4>
    <div class="list-group text-left">
      <a class="list-group-item">
        <i class="fa fa fa-file-archive-o fa-fw"></i> File Format
        <span class="pull-right text-muted">';

        if($format_status){ 
          $html .= "<span class='text-success'><i class='fa fa-check'></i> VALID </span>"; 
        }else{
          $html .= "<span class='text-danger'><i class='fa fa-times'></i> NOT VALID </span>";
        }
        $html .= '</span></a>

      <a class="list-group-item">
        <i class="fa fa-tags fa-fw"></i> Digital Signature
        <span class="pull-right text-muted">';
        if($digital_signature){ 
          $html .= "<span class='text-success'><i class='fa fa-check'></i> VALID </span>"; 
        }else{
          $html .= "<span class='text-danger'><i class='fa fa-times'></i> NOT VALID </span>";
        }
        $html .= '</span></a>
    </div>';
    
    $html .= "<h3><code> STATUS REPORT </code></h3>";
    if($digital_signature){
      $html .= '<hp class="text-success"><i class="fa fa-check"></i> The '.$file_category.' is AUTHENTIC. </p>';
    }else{
      $html .= '<p class="text-danger"><i class="fa fa-warning"></i> The integrity of this '.$file_category.' has been Compromised. </p>';
    }

    $html .= '<p class="">'. $status_report. '</p>';

//$html .= '<br /><div class="row"><div class="col-lg-12">Characters: '. $num_chars.'</div></div>';
//$html .= '<br /><div class="row"><div class="col-lg-12">'. $hex_value.'</div></div>';
echo $html;

?>

<?php include_once("partials/footer.php"); ?>