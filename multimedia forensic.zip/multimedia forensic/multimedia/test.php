<?php include_once("partials/header.php"); ?>

<?php 
  $sql_query = mysqli_query($connection, "SELECT * FROM file_analysis");
  while($row = mysqli_fetch_assoc($sql_query) ){
    $file_name = $row['f_name'];
    $file_size = $row['f_size'];
    $f_type = $row['f_type'];
    $directory = $row['directory'];
    $hex_value = $row['hex_value'];
    $num_chars = $row['num_chars'];
    $c_time = date ("F d Y, H:i:s", filectime($directory));
    $m_time = date ("F d Y, H:i:s", filemtime($directory));

    $file_type = explode("/", $f_type);
    $file_category = $file_type[0];
    $file_format = $file_type[1];
    $hex = explode(" ", $hex_value);
  }

  //ANALYSIS OUTPUT
  $format_status = false;
  $digital_signature = false;
  $status_report = "";
  $signature_type = "";
  $signature_subtype = "";

  //perform VIDEO analysis
  function videoAnalysis(){
    global $connection, $format_status, $digital_signature, $hex, $num_chars, $file_format;
    global $signature_type, $signature_subtype, $status_report;

    //SQL TO GET FILE SIGNATURE TYPES
    $sql_query = mysqli_query($connection, "SELECT * FROM video WHERE file_format = '{$file_format}' ");
    while($row = mysqli_fetch_array($sql_query) ){
      $all_types = $row['signature_type'];
      $all_subtypes = $row['signature_subtype'];
    }

    //create arrays of signature types and subtypes
    $signature_type = explode(",", $all_types);
    $signature_subtype = explode(",", $all_subtypes);
    
    //======================================
              //MP4 AUTHENTICATION
    //=====================================
    function mp4Authentication(){    
      global $connection, $format_status, $digital_signature, $hex, $num_chars, $file_format;
      global $signature_type, $signature_subtype, $status_report;

      //DATA FROM THE FIRST CHUNK
      $firstChunk_size = $hex[0] + $hex[1] + $hex[2] + $hex[3];
      $firstChunk_type = chr($hex[4]).chr($hex[5]).chr($hex[6]).chr($hex[7]); //convert back to ascii character
      $firstChunk_subtype = chr($hex[8]). chr($hex[9]).chr($hex[10]). chr($hex[11]);
        
      //VERIFY THE FIRST CHUNK
      if( ($firstChunk_type) === $signature_type[0] ){ //$first_chunk_type
        for($i = 0; $i < sizeof($signature_subtype); $i++){//verify from the signature sub types from the database
          if( in_array($firstChunk_subtype, $signature_subtype) ){ //$first_chunk_subtype
            $format_status = true; // has a valid format type

            //create second chunk data
            $secondChunk_offset = $firstChunk_size;
            $secondChunk_size = $hex[$secondChunk_offset] + $hex[$secondChunk_offset+1] + $hex[$secondChunk_offset+2] + $hex[$secondChunk_offset+3];
            $secondChunk_type = chr($hex[$secondChunk_offset+4]). chr($hex[$secondChunk_offset+5]). chr($hex[$secondChunk_offset+6]). chr($hex[$secondChunk_offset+7]);

          }else{ // break away from the loop if the subtype is not valid
            $format_status = false;
            $status_report .= "<p>The video is NOT a valid mp4 file, and the DIGITAL Signature is not verified.</p>";
            break;
          }
        }

        if($format_status){
          //PERFORM CHECKS FROM THE 16TH - 23RD OFFSET LOCATION
          $sixtent_offset = chr($hex[16]).chr($hex[17]).chr($hex[18]).chr($hex[19]); //offset location between 16 - 19
          $twentiet_offset = chr($hex[20]).chr($hex[21]).chr($hex[22]).chr($hex[23]); //offset location between 20 - 23

          //VERIFY THE SECOND CHUNK
          for($i = 0; $i < sizeof($signature_type); $i++){//verify from the signature sub types from the database
            if( in_array($secondChunk_type, $signature_type) ){ //$first_chunk_subtype
              //offset location between 16 -  - 23
              if( in_array($sixtent_offset, $signature_subtype) && in_array($twentiet_offset, $signature_subtype)  ){ 
                
                if( ($sixtent_offset === "MSNV") || ($twentiet_offset === "MSNV") ){ //recorded from web cameras
                  $digital_signature = true;
                  $status_report = "<p>The video is a valid mp4 file, and the DIGITAL Signature is VERIFIED.</p>";
                }if( ($sixtent_offset === "MSNV") || ($twentiet_offset === "MSNV") ){ //recorded with a mobile phone
                  $digital_signature = true;
                  $status_report = "<p>The video is a valid mp4 file, and the DIGITAL Signature is VERIFIED.</p>";
                }else{ // INVALID SIGNATURE
                  if( ($sixtent_offset === "mp41") && ($twentiet_offset === "isom") ){
                    $status_report = "<p><b>REASON:</b> Some frames were removed from the original copy. </p>";
                  }else if( ($sixtent_offset === "isom") && ($twentiet_offset === "iso2") ){
                    $status_report = "<p><b>REASON:</b> The frames were converted from another format. </p>";
                  }else{
                    //$digital_signature = true;
                    $status_report = "<p>The video is a valid mp4 file, but the DIGITAL Signature is not verified.</p>";
                  }
                  
                }

              }else{ 
                $status_report = "<p>The video is a valid mp4 file, but the DIGITAL Signature is not verified.</p>";
                break; // break away from the loop if the //offset location between 16 - 23 is not valid
              }
            }else{ 
              $status_report = "<p>The video is a valid mp4 file, but the DIGITAL Signature is not verified.</p>";
              break; // break away from the loop if the $secondChunk_type is not valid
            }
          }
          if(isset($subs)){echo $subs;}
        }
        

        //VERIFY THE SECOND CHUNK
        // if($secondChunk_size > $firstChunk_size){
        //   for($i = 0; $i < sizeof($signature_type); $i++){//verify from the signature sub types from the database
        //     if( in_array($secondChunk_type, $signature_type) ){ //$first_chunk_subtype
        //       //$format_status = true; // has a valid format type
        //       //create third chunk data
        //       //$digital_signature = true;
        //       // $thirdChunk_offset = $firstChunk_size + $secondChunk_size;
        //       // $thirdChunk_size = $hex[$thirdChunk_offset] + $hex[$thirdChunk_offset+1] + $hex[$thirdChunk_offset+2] + $hex[$thirdChunk_offset+3];
        //       // $thirdChunk_type = chr($hex[$thirdChunk_offset+4]). chr($hex[$thirdChunk_offset+5]). chr($hex[$thirdChunk_offset+6]). chr($hex[$thirdChunk_offset+7]);
        //     }else{ // break away from the loop if the subtype is not valid
        //       // $digital_signature = false;
        //       // break;
        //     }
        //   }
        // }else{
        //   $digital_signature = false;
        // }

        //VERIFY THE THIRD CHUNK
        // if(isset($thirdChunk_size) && ($thirdChunk_size < $num_chars)){
        //   if($thirdChunk_size > 0){
        //     for($i = 0; $i < sizeof($signature_type); $i++){//verify from the signature sub types from the database
        //       if( in_array($thirdChunk_type, $signature_type) ){ //$first_chunk_subtype
        //         //create fourth chunk data
        //         $digital_signature = true; // has a valid format type
        //         $fourthChunk_offset = $firstChunk_size + $secondChunk_size + $thirdChunk_size;
        //         $fourthChunk_size = $hex[$fourthChunk_offset] + $hex[$fourthChunk_offset+1] + $hex[$fourthChunk_offset+2] + $hex[$fourthChunk_offset+3];
        //         $fourthChunk_type = chr($hex[$fourthChunk_offset+4]). chr($hex[$fourthChunk_offset+5]). chr($hex[$fourthChunk_offset+6]). chr($hex[$fourthChunk_offset+7]);
        //       }else{ // break away from the loop if the subtype is not valid
        //         $digital_signature = false;
        //         break;
        //       }
        //     }
        //   }else{
        //     $digital_signature = false;
        //   }
        // }

        //VERIFY THE FOURTH CHUNK
        // if(isset($fourthChunk_size) && ($fourthChunk_size < $num_chars)){
        //   if($fourthChunk_size > 0){
        //     for($i = 0; $i < sizeof($signature_type); $i++){//verify from the signature sub types from the database
        //       if( in_array($fourthChunk_type, $signature_type) ){ //$first_chunk_subtype
        //         //create fifth chunk data
        //         $digital_signature = true; // has a valid format type
        //         $fifthChunk_offset = $firstChunk_size + $secondChunk_size + $thirdChunk_size + $fourthChunk_size;
        //         $fifthChunk_size = $hex[$fifthChunk_offset] + $hex[$fifthChunk_offset+1] + $hex[$fifthChunk_offset+2] + $hex[$fifthChunk_offset+3];
        //         $fifthChunk_type = chr($hex[$fifthChunk_offset+4]). chr($hex[$fifthChunk_offset+5]). chr($hex[$fifthChunk_offset+6]). chr($hex[$fifthChunk_offset+7]);
        //       }else{ // break away from the loop if the subtype is not valid
        //         $digital_signature = false;
        //         break;
        //       }
        //     }
        //   }else{
        //     $digital_signature = false;
        //   }
        // }

        //echo $sc_offset;
        // echo "Offset ". $fourthChunk_offset.", ";
        // echo "size: ". $fourthChunk_size.", "; // $hex[$fc_size] + $hex[$fc_size];// + $hex[$fc_size+2] + $hex[$fc_size+3];
        // echo "type: ". $fourthChunk_type.", "; //$hex[$fc_size+4] + $hex[$fc_size+5] + $hex[$fc_size+6] + $hex[$fc_size+7];
        
      }//valid first chunk type ends...
    }//.MP4 AUTHENTICATION ENDS...

    if($file_format === "mp4"){
      mp4Authentication();
    }

  }// end of VIDEO analysis...

  //perform IMAGE analysis
  function imageAnalysis(){
    global $connection, $format_status, $digital_signature, $hex, $num_chars, $file_format;
    global $signature_type, $signature_subtype, $status_report;

    //SQL TO GET FILE SIGNATURE TYPES
    $sql_query = mysqli_query($connection, "SELECT * FROM `image` WHERE file_format = '{$file_format}' ");
    while($row = mysqli_fetch_array($sql_query) ){
      $all_types = $row['signature_type'];
      $all_subtypes = $row['signature_subtype'];
    }

    //create arrays of signature types and subtypes
    $signature_type = explode(",", $all_types);
    $signature_subtype = explode(",", $all_subtypes);
    
    //======================================
              //JPG AUTHENTICATION
    //=====================================
    function jpgAuthentication(){    
      global $connection, $format_status, $digital_signature, $hex, $num_chars, $file_format;
      global $signature_type, $signature_subtype, $status_report;

      //DATA FROM THE FIRST CHUNK
      $firstChunk_size = $hex[0] + $hex[1] + $hex[2] + $hex[3];
      $firstChunk_type = chr($hex[4]).chr($hex[5]).chr($hex[6]).chr($hex[7]); //convert back to ascii character
      $firstChunk_subtype = chr($hex[8]). chr($hex[9]).chr($hex[10]). chr($hex[11]);
        
      //VERIFY THE FIRST CHUNK
      if( ($firstChunk_type) === $signature_type[0] ){ //$first_chunk_type
        for($i = 0; $i < sizeof($signature_subtype); $i++){//verify from the signature sub types from the database
          if( in_array($firstChunk_subtype, $signature_subtype) ){ //$first_chunk_subtype
            $format_status = true; // has a valid format type

            //create second chunk data
            $secondChunk_offset = $firstChunk_size;
            $secondChunk_size = $hex[$secondChunk_offset] + $hex[$secondChunk_offset+1] + $hex[$secondChunk_offset+2] + $hex[$secondChunk_offset+3];
            $secondChunk_type = chr($hex[$secondChunk_offset+4]). chr($hex[$secondChunk_offset+5]). chr($hex[$secondChunk_offset+6]). chr($hex[$secondChunk_offset+7]);

          }else{ // break away from the loop if the subtype is not valid
            $format_status = false;
            $status_report .= "<p>The video is NOT a valid mp4 file, and the DIGITAL Signature is not verified.</p>";
            break;
          }
        }

        if($format_status){
          //PERFORM CHECKS FROM THE 16TH - 23RD OFFSET LOCATION
          $sixtent_offset = chr($hex[16]).chr($hex[17]).chr($hex[18]).chr($hex[19]); //offset location between 16 - 19
          $twentiet_offset = chr($hex[20]).chr($hex[21]).chr($hex[22]).chr($hex[23]); //offset location between 20 - 23

          //VERIFY THE SECOND CHUNK
          for($i = 0; $i < sizeof($signature_type); $i++){//verify from the signature sub types from the database
            if( in_array($secondChunk_type, $signature_type) ){ //$first_chunk_subtype
              //offset location between 16 -  - 23
              if( in_array($sixtent_offset, $signature_subtype) && in_array($twentiet_offset, $signature_subtype)  ){ 
                
                if( ($sixtent_offset === "MSNV") || ($twentiet_offset === "MSNV") ){ //recorded from web cameras
                  $digital_signature = true;
                  $status_report = "<p>The video is a valid mp4 file, and the DIGITAL Signature is VERIFIED.</p>";
                }if( ($sixtent_offset === "MSNV") || ($twentiet_offset === "MSNV") ){ //recorded with a mobile phone
                  $digital_signature = true;
                  $status_report = "<p>The video is a valid mp4 file, and the DIGITAL Signature is VERIFIED.</p>";
                }else{ // INVALID SIGNATURE
                  if( ($sixtent_offset === "mp41") && ($twentiet_offset === "isom") ){
                    $status_report = "<p>REASON: Some frames were removed from the original copy. </p>";
                  }else if( ($sixtent_offset === "isom") && ($twentiet_offset === "iso2") ){
                    $status_report = "<p>REASON: The frames were converted from another format. </p>";
                  }else{
                    //$digital_signature = true;
                    $status_report = "<p>The video is a valid mp4 file, but the DIGITAL Signature is not verified.</p>";
                  }
                  
                }

              }else{ 
                $status_report = "<p>The video is a valid mp4 file, but the DIGITAL Signature is not verified.</p>";
                break; // break away from the loop if the //offset location between 16 - 23 is not valid
              }
            }else{ 
              $status_report = "<p>The video is a valid mp4 file, but the DIGITAL Signature is not verified.</p>";
              break; // break away from the loop if the $secondChunk_type is not valid
            }
          }
          
        }
        
        
      }//valid first chunk type ends...
    }//.MP4 AUTHENTICATION ENDS...

    if($file_format === "jpg"){
      jpgAuthentication();
    }
  }// end of IMAGE analysis...

  //perform AUDIO analysis
  function audioAnalysis(){
    global $connection, $format_status, $digital_signature, $hex, $num_chars, $file_format;
    global $signature_type, $signature_subtype, $status_report;

    //SQL TO GET FILE SIGNATURE TYPES
    $sql_query = mysqli_query($connection, "SELECT * FROM `audio` WHERE file_format = '{$file_format}' ");
    while($row = mysqli_fetch_array($sql_query) ){
      $all_types = $row['signature_type'];
      $all_subtypes = $row['signature_subtype'];
    }

    //create arrays of signature types and subtypes
    $signature_type = explode(",", $all_types);
    $signature_subtype = explode(",", $all_subtypes);
    
    //======================================
              //MP3 AUTHENTICATION
    //=====================================
    function mp3Authentication(){    
      global $connection, $format_status, $digital_signature, $hex, $num_chars, $file_format;
      global $signature_type, $signature_subtype, $status_report;

      //DATA FROM THE FIRST CHUNK
      $firstChunk_size = $hex[0] + $hex[1] + $hex[2] + $hex[3];
      $firstChunk_type = chr($hex[4]).chr($hex[5]).chr($hex[6]).chr($hex[7]); //convert back to ascii character
      $firstChunk_subtype = chr($hex[8]). chr($hex[9]).chr($hex[10]). chr($hex[11]);
        
      //VERIFY THE FIRST CHUNK
      if( ($firstChunk_type) === $signature_type[0] ){ //$first_chunk_type
        for($i = 0; $i < sizeof($signature_subtype); $i++){//verify from the signature sub types from the database
          if( in_array($firstChunk_subtype, $signature_subtype) ){ //$first_chunk_subtype
            $format_status = true; // has a valid format type

            //create second chunk data
            $secondChunk_offset = $firstChunk_size;
            $secondChunk_size = $hex[$secondChunk_offset] + $hex[$secondChunk_offset+1] + $hex[$secondChunk_offset+2] + $hex[$secondChunk_offset+3];
            $secondChunk_type = chr($hex[$secondChunk_offset+4]). chr($hex[$secondChunk_offset+5]). chr($hex[$secondChunk_offset+6]). chr($hex[$secondChunk_offset+7]);

          }else{ // break away from the loop if the subtype is not valid
            $format_status = false;
            $status_report .= "<p>The video is NOT a valid mp4 file, and the DIGITAL Signature is not verified.</p>";
            break;
          }
        }

        if($format_status){
          //PERFORM CHECKS FROM THE 16TH - 23RD OFFSET LOCATION
          $sixtent_offset = chr($hex[16]).chr($hex[17]).chr($hex[18]).chr($hex[19]); //offset location between 16 - 19
          $twentiet_offset = chr($hex[20]).chr($hex[21]).chr($hex[22]).chr($hex[23]); //offset location between 20 - 23

          //VERIFY THE SECOND CHUNK
          for($i = 0; $i < sizeof($signature_type); $i++){//verify from the signature sub types from the database
            if( in_array($secondChunk_type, $signature_type) ){ //$first_chunk_subtype
              //offset location between 16 -  - 23
              if( in_array($sixtent_offset, $signature_subtype) && in_array($twentiet_offset, $signature_subtype)  ){ 
                
                if( ($sixtent_offset === "MSNV") || ($twentiet_offset === "MSNV") ){ //recorded from web cameras
                  $digital_signature = true;
                  $status_report = "<p>The video is a valid mp4 file, and the DIGITAL Signature is VERIFIED.</p>";
                }if( ($sixtent_offset === "MSNV") || ($twentiet_offset === "MSNV") ){ //recorded with a mobile phone
                  $digital_signature = true;
                  $status_report = "<p>The video is a valid mp4 file, and the DIGITAL Signature is VERIFIED.</p>";
                }else{ // INVALID SIGNATURE
                  if( ($sixtent_offset === "mp41") && ($twentiet_offset === "isom") ){
                    $status_report = "<p>REASON: Some frames were removed from the original copy. </p>";
                  }else if( ($sixtent_offset === "isom") && ($twentiet_offset === "iso2") ){
                    $status_report = "<p>REASON: The frames were converted from another format. </p>";
                  }else{
                    //$digital_signature = true;
                    $status_report = "<p>The video is a valid mp4 file, but the DIGITAL Signature is not verified.</p>";
                  }
                  
                }

              }else{ 
                $status_report = "<p>The video is a valid mp4 file, but the DIGITAL Signature is not verified.</p>";
                break; // break away from the loop if the //offset location between 16 - 23 is not valid
              }
            }else{ 
              $status_report = "<p>The video is a valid mp4 file, but the DIGITAL Signature is not verified.</p>";
              break; // break away from the loop if the $secondChunk_type is not valid
            }
          }
          
        }
        
        
      }//valid first chunk type ends...
    }//.MP3 AUTHENTICATION ENDS...

    if($file_format === "mp3"){
      mp3Authentication();
    }
  }// end of AUDIO analysis...

  //CHOOSE THE FUNCTION TO CALL BASED ON THE FILE TYPE
  if($file_category === "video"){
    videoAnalysis();
  }
  // else if($file_category === "audio"){

  // }else if($file_category === "image"){

  // }else{

  // }
 

  //COMPILE THE FIRST PART OF THE REPORT IN HTML
  
  $html = '
    <br /><div class="row"><div class="col-lg-12"></div></div>

    <h4 class="text-left"><code><i class="fa fa-tasks"></i> UPLOADED FILE DETAILS</code></h4>
    <div class="list-group text-left">
      <a class="list-group-item">
          <i class="fa fa fa-file-archive-o fa-fw"></i> File Type
          <span class="pull-right text-muted">'.$file_category.'</span></a>

      <a class="list-group-item">
        <i class="fa fa fa-filter fa-fw"></i> Format
        <span class="pull-right text-muted">'.$file_format.'</span></a>

      <a class="list-group-item">
        <i class="fa fa-tags fa-fw"></i> Name
        <span class="pull-right text-muted">'.$file_name.'</span></a>

      <a class="list-group-item">
          <i class="fa fa-hdd-o"></i> File size
          <span class="pull-right text-muted">'.number_format(floor($file_size/1024),0). ' KB</span></a>

      <a class="list-group-item">
          <i class="fa fa-calendar fa-fw"></i> Creation Date
          <span class="pull-right text-muted">'.$c_time.'</span></a>

      <a class="list-group-item">
          <i class="fa fa-calendar fa-fw"></i> Date Modified
          <span class="pull-right text-muted">'.$m_time.'</span></a>
    </div>

    <br />
    <h4 class="text-left"><kbd><i class="fa fa-refresh"></i> RESULT OF FILE ANALYSIS </kbd></h4>
    <div class="list-group text-left">
      <a class="list-group-item">
        <i class="fa fa fa-file-archive-o fa-fw"></i> File Format
        <span class="pull-right text-muted">';

        if($format_status){ 
          $html .= "<span class='text-success'><i class='fa fa-check'></i> VALID </span>"; 
        }else{
          $html .= "<span class='text-danger'><i class='fa fa-times'></i> NOT VALID </span>";
        }
        $html .= '</span></a>

      <a class="list-group-item">
        <i class="fa fa-tags fa-fw"></i> Digital Signature
        <span class="pull-right text-muted">';
        if($digital_signature){ 
          $html .= "<span class='text-success'><i class='fa fa-check'></i> VALID </span>"; 
        }else{
          $html .= "<span class='text-danger'><i class='fa fa-times'></i> NOT VALID </span>";
        }
        $html .= '</span></a>
    </div>';
    
    $html .= "<h3><code> STATUS REPORT </code></h3>";
    if($digital_signature){
      $html .= '<hp class="text-success"><i class="fa fa-check"></i> The integrity of this '.$file_category.' is Authentic. </p>';
    }else{
      $html .= '<p class="text-danger"><i class="fa fa-warning"></i> The integrity of this '.$file_category.' has been Compromised. </p>';
    }

    $html .= '<p class="">'. $status_report. '</p>';

//$html .= '<br /><div class="row"><div class="col-lg-12">Characters: '. $num_chars.'</div></div>';
//$html .= '<br /><div class="row"><div class="col-lg-12">'. $hex_value.'</div></div>';
echo $html;

?>




<?php 
  //step 1. connection to database

  $db_connection = mysqli_connect("lhost", "root", "password", "db");

  
  //step2. create sql statement to get the data.
    $sql = "SELECT * FROM users WHERE user_id = '{$user_id}' ";


  //step 3. execute the query
    $run_sql = mysqli_query($db_connection, $sql);


  //step 4. store query result in an array
  while($result = mysqli_fetch_array($run_sql)){
    $name = $result['name'];
    $phone = $result['number'];

  }
?>

  //step 5. display array result in a table
  <table>
    <tr>
      <td>User name</td>
      <td><?php echo $name; ?></td>
    </tr>

    <tr>
      <td>Phone NUmber</td>
      <td><?php echo $phone; ?></td>
    </tr>
  </table>


