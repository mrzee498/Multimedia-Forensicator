<?php include_once("partials/connections.php"); ?>
<?php include_once("partials/functions.php"); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Multimedia Forensicator</title>
	<link type="text/css" rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />
  <link rel="stylesheet" href="assets/bootstrap/fonts/font-awesome.min.css">
  <link href="../assets/img/icon.PNG" rel="icon" type="image/x-icon">
</head>