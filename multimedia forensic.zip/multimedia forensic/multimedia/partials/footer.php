<script type="text/javascript" src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>


<?php 
ob_end_flush();

	//CLOSE DATABASE CONNECTION IF IT HAS BEEN OPENED.
	if ($connection) {
		mysqli_close($connection);
	}
?>