<?php
  require_once('vendor/autoload.php');
  use wapmorgan\MediaFile\MediaFile;
  
  //BASIC REDIRECTION FUNCTION
  function redirect_to($location){
    header("Location: $location");
    exit;
  }


?>