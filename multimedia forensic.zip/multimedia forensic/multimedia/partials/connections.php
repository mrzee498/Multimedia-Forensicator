<?php
	require_once("constants.php");
	@$connection = mysqli_connect(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE);

	if(!$connection){
		die ("<h4>Connection to SERVER  failed.</h4>");
	}
?>