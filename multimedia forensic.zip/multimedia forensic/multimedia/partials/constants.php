<?php
  //DATABASE CRENDENTIALS
	define('DB_HOSTNAME', 'localhost');
	define('DB_USERNAME', 'root');
	define('DB_PASSWORD', '');
  define('DB_DATABASE', 'multimedia_forensic');

?>