<?php ob_start(); ?>
<?php require_once("partials/connections.php"); ?>
<?php require_once("partials/functions.php"); ?>
<?php  

if(isset($_POST['btnUpload'])){
  $file_name = $_FILES['file_upload']['name'];
  $file_type = $_FILES['file_upload']['type'];
  $file_size = $_FILES['file_upload']['size'];
  $temp_name = $_FILES['file_upload']['tmp_name'];
  $new_dir = "uploads/".$file_name;
  $file_content = ($new_dir);

  //perform audio analysis
  function audioAnalysis(){
    global $file_name, $file_type, $file_size, $temp_name, $new_dir;
 
    $log_success = "Audio upload Successful!";
    return header("Location: index.php?log_success=$log_success&name=$file_name&type=$file_type&size=$file_size");
  }

  //perform video analysis
  function videoAnalysis(){
    global $file_name, $file_type, $file_size, $temp_name, $new_dir;

    $log_success = "Video upload Successful!";
    return header("Location: index.php?log_success=$log_success&name=$file_name&type=$file_type&size=$file_size");
  }

  //perform image analysis
  function imageAnalysis(){
    global $file_name, $file_type, $file_size, $temp_name, $new_dir;

    $log_success = "Image upload Successful!";
    return header("Location: index.php?log_success=$log_success&name=$file_name&type=$file_type&size=$file_size");
  }

  //file_upload();
  if($file_name){ // YES FILE      
    if( ($file_type === "audio/mp3") || ($file_type === "video/mp4") || ($file_type === "image/jpeg") || ($file_type === "image/jpg") ) { 
      // YES FORMAT
      $moved = move_uploaded_file($temp_name, $new_dir);

      if($moved){ // YES UPLOAD

        $handle = fopen($file_content, "rb");
        $fsize = filesize($file_content);
        $contents = fread($handle, $fsize);
        fclose($handle);

        // iterate through each byte in the contents
        $comp_hex = "";
        $num_characters = 0;
        for($i = 0; $i < $fsize; $i++){
          $asciiCharacter = $contents[$i];
          // get the base 10 value of the current characer
          $base10value = ord($asciiCharacter);
          $comp_hex .= $base10value." ";
          $num_characters += 1;
        }
        
        //CHECK IF DB HAVE ANY RECORD
        $sql_run = mysqli_query($connection, "SELECT * FROM file_analysis");
        $rec_exist = mysqli_num_rows($sql_run);

        if($rec_exist < 1){ // first time use of the software
          $sql = "INSERT INTO file_analysis(
            f_name, f_type, f_size, directory, hex_value, num_chars
          ) VALUES(
            '{$file_name}', '{$file_type}', '{$file_size}', '{$new_dir}', '{$comp_hex}', '{$num_characters}'
          )";
        }else{ // existing user
          $sql = "UPDATE file_analysis SET
            f_name = '{$file_name}',
            f_type = '{$file_type}',
            f_size = '{$file_size}',
            directory = '{$new_dir}',
            hex_value = '{$comp_hex}',
            num_chars = '{$num_characters}'
          ";
        }

        //hex_value = LOAD_FILE('uploads/test_image.jpg')
        $sql_query = mysqli_query($connection, $sql);
        //$num_rows = mysqli_num_rows($sql_query);

        if($sql_query){ //sql query successful
          if($file_type == "audio/mp3"){
            audioAnalysis();
            //echo "audio uploaded";
          }else if($file_type == "video/mp4"){
            videoAnalysis();
            //echo "video uploaded";
          }else{
            imageAnalysis();
            //echo "image uploaded";
          }
        }else{ //sql query failed
          $log_error = "Server error: file upload failed <br />".mysqli_error($connection);
          header("Location: index.php?log_error=$log_error");
        }
      }else{ // FILE UPLOAD FAILED
        $log_error = "file upload failed. Please Try Again.";
        header("Location: index.php?log_error=$log_error");
      }
    }else{ //NO FORMAT
      $log_error = "please select appropriate file format";
      header("Location: index.php?log_error=$log_error");
    }
  }else{ // NO FILE
    $log_error = "Please choose a file first.";
    header("Location: index.php?log_error=$log_error");
  }// if(!empty($name))
}

?>

<?php include_once("partials/footer.php"); ?>